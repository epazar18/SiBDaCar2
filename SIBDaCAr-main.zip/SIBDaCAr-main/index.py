

from operator import index
from flask import Flask, render_template,request,session,redirect,url_for
from flask_sqlalchemy import SQLAlchemy
from utils.db import db
from model import Usuario
from flask_login import LoginManager
app = Flask(__name__)

app.secret_key='root'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@localhost/forenses'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
SQLAlchemy(app)
usuarios=[]
usuarios.append(Usuario(nombre='Paola',apellido='Azar',dni=123,nbre_usuario='root',email='pp@pp',clave='root'))

# Routes to Render Something
@app.route('/')
def index():    
    return render_template("index.html")

@app.route('/home', strict_slashes=False)
def home():
    return render_template("home.html")

@app.route('/expedientes', strict_slashes=False)
def expedientes():
    return render_template("expedientes.html")

@app.route('/NuevaAutopsia', strict_slashes=False)
def NuevaAutopsia():
    return render_template("newAutopsia.html")

@app.route('/NuevoExpediente', strict_slashes=False)
def NuevoExpediente():
    return render_template("newExpediente.html")

@app.route('/NuevoCadaver', strict_slashes=False)
def NuevoCadaver():
    return render_template("newCadaver.html")
    
@app.route('/login',methods=['POST'])
def login():
    
    if request.method=='POST':
        session.pop('user_id',None)
        usuario=request.form['usuario']
        passw=request.form['password']        
        user =[x for x in usuarios if x.nbre_usuario==usuario][0]    
        if user and user.clave == passw:
            session['user_id']=passw
            return redirect(url_for('home'))
        return redirect(url_for('NuevaAutopsia'))
    return redirect(url_for('NuevoExpediente'))


@app.route('/registro',methods=['POST'])
def registro():
    nbre=request.form.get('new_nbre')   
    usuario=request.form.get('usuario')
    dni=request.form.get('new_dni')
    apellido=request.form.get('new_apelllido')
    email=request.form.get('new_email')
    clave=request.form.get('new_clave')
    nuevo_usuario=Usuario(nbre,apellido,dni,usuario,email,clave)
    db.session.add(nuevo_usuario)
    db.session.commit()
    return "registro realizado"

#with app.app_context():
#    db.create_all()

# Make sure this we are executing this file
if __name__ == '__main__':
    app.run(debug=True)