# SIBDaCAr
proyecto 

Levantar el proyecto de forma local
1- abrir cmd o power shell
2- ubicarme en la carpeta del proyecto cd  C:\Desktop\SIBDaCAr
3- comando para levantar proyecto en localhost:  python index.py 
4- Abrir en navegador dirección: http://localhost:5000
