from utils.db import db

class Usuario(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    nombre=db.Column(db.String(100))
    apellido=db.Column(db.String(100))
    dni=db.Column(db.Integer)
    nbre_usuario=db.Column(db.String(50))    
    email=db.Column(db.String(60))
    clave=db.Column(db.String(50))
    
    def __init__(self,nombre,apellido,dni,nbre_usuario,email,clave):
        self.nombre=nombre
        self.apellido=apellido
        self.clave=clave
        self.dni=dni
        self.email=email
        self.nbre_usuario=nbre_usuario