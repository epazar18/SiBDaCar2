var myModal = new bootstrap.Modal(document.getElementById("#exampleModal"), {});
document.onreadystatechange = function () {
  myModal.show();
};